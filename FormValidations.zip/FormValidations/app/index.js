"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
var my_form_component_ts_1 = require("./my-form.component.ts");
platform_browser_dynamic_1.bootstrap(my_form_component_ts_1.MyForm);
