"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var custom_validators_1 = require("./custom-validators");
var MyForm = (function () {
    function MyForm(builder) {
        this.email = new common_1.Control('', common_1.Validators.compose([common_1.Validators.required, custom_validators_1.CustomValidators.emailFormat]));
        this.password = new common_1.Control('', common_1.Validators.compose([common_1.Validators.required, common_1.Validators.minLength(4)]));
        this.group = builder.group({
            email: this.email,
            password: this.password
        });
    }
    MyForm.prototype.onSubmit = function () {
        console.log(this.group.value);
    };
    MyForm = __decorate([
        core_1.Component({
            selector: 'my-form',
            templateUrl: 'app/my-form.component.html',
            directives: [common_1.FORM_DIRECTIVES],
            styleUrls: ['styles.css']
        })
    ], MyForm);
    return MyForm;
}());
exports.MyForm = MyForm;
