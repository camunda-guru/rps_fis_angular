import { Component, ViewChild } from '@angular/core';
import {MyChildComponent} from './myChild.component';

@Component({
  selector: 'my-app',
  templateUrl:'../../views/parentpage.html',

  
})
export class ParentComponent {
   @ViewChild(MyChildComponent)
     private myChild: MyChildComponent;

   openTab(){		
		this.myChild.showPage(2,'2');	   
   }
}