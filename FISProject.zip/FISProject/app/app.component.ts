import {Component} from "@angular/core";


@Component({
    selector:'fis-logo',
    templateUrl:"../views/app.template.html",
    styleUrls:["../styles/app.styles.css"]
})
export class AppComponent{

    private logoPath:string="../assets/fislogo.jpg";

}