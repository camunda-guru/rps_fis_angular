import { Hero } from './hero';

export const HEROES: Hero[] = [
  { id: 2001, name: 'Mr. Anoop' },
  { id: 2002, name: 'Janani' },
  { id: 2003, name: 'Bahubali' },
  { id: 2004, name: 'Charulatha' },
  { id: 2005, name: 'Madan' },
  { id: 2345, name: 'Ranjit' },
  { id: 7811, name: 'Dyana' },
  { id: 9811, name: 'Dr John' },
  { id: 1978, name: 'Magna' },
  { id: 1390, name: 'Tamil' }
];

