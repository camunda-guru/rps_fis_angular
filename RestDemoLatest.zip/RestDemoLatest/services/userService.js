bankingApp.service('UserService',['$http',function($http)
{
    var userPromise=function()
    {
        return $http({
            method:'GET',
            dataType:"json",
            headers:{

                "content-type":"application/json"
            },

            url:"https://jsonplaceholder.typicode.com/users"
        }).then(function(response)
        {
            return response;
        })
    }


    return{
        userServiceObj:userPromise
    }
}])
bankingApp.service('CountryService',['$http',function($http)
{
    var countryPromise=function()
    {
        return $http({
            method:'GET',
            dataType:"json",
            headers:{

                "content-type":"application/json"
            },

            url:"https://restcountries.eu/rest/v2/all"
        }).then(function(response)
        {
            return response;
        })
    }


    return{
        countryServiceObj:countryPromise
    }
}])