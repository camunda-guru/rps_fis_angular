bankingApp.controller('CustomerController',['$scope','UserService','CountryService',function($scope,UserService,CountryService)
{

 console.log(window.navigator.language);

$scope.countryName="";
$scope.currentDate=new Date();
$scope.totalAmt=435689;

$scope.change=function()
{
    console.log("Selected Value....",$scope.countryName);
}

UserService.userServiceObj().then(function(response)
{
    console.log(response);
    $scope.userData=response.data;
})

CountryService.countryServiceObj().then(function(response)
{
    $scope.countryArr=[];
    angular.forEach(response.data,function(data)
    {
        //console.log(data);
        obj={
            name:data.name,
            code:data.alpha3Code
        }
        $scope.countryArr.push(obj);
    })

    console.log($scope.countryArr);
})


}])