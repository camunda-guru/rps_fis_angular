/**
 * Created by BALASUBRAMANIAM on 01-12-2015.
 */
tradingMenu=[

    {"type":"Agricultural"},
    {"type":"Energy"},
    {"type":"Equity Index"},
    {"type":"FX"},
    {"type":"Interest Rates"},
    {"type":"Metals"},
    {"type":"Options"},
    {"type":"OTC"},
    {"type":"Weather"},
    {"type":"Real Estate"},
    {"type":"Metals"},
    {"type":"Options"},
    {"type":"OTC"},
    {"type":"Weather"},
    {"type":"Real Estate"}
];

