/**
 * Created by BALASUBRAMANIAM on 01-12-2015.
 */
$(window).load(function()
{
    $('#pills-first a').hover(function (e) {
        e.preventDefault()
        $('#trading').empty();
        div=$('<div></div>').addClass("test");

        ul=$('<ul></ul>');
        ul.appendTo(div);
        $('#trading').append(div);


        $.each(tradingMenu,function(key,value)
        {

            ul.append('<li><span class=\"listText\">'+value.type
            +'</span></li>');
        });

        $(this).tab('show')
    });


});