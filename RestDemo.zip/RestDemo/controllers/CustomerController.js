bankingApp.controller('CustomerController',['$scope',function($scope)
{

    $scope.customerObj={
        customerId:0,
        name:"",
        address:""
    }

    $scope.save=function()
    {
        console.log($scope.customerObj);
    }
}])