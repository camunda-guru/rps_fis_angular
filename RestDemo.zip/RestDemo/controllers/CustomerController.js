bankingApp.controller('CustomerController',['$scope',function($scope)
{

    $scope.customerObj={
        customerId:3589679,
        name:"Arun",
        address:"Chennai"
    }

}])